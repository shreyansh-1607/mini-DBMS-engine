// Not a real engine test — just confirms GoogleTest + CMake + FetchContent
// are wired together correctly before Phase 1 code exists. Delete this file
// once disk_manager_test.cpp (Phase 1) lands.
#include <gtest/gtest.h>

#include "common/config.h"

TEST(SanityTest, BuildIsWorking) { EXPECT_EQ(1 + 1, 2); }

TEST(SanityTest, ConfigConstantsAreSane) {
  EXPECT_GT(rdbms::PAGE_SIZE, 0u);
  EXPECT_GT(rdbms::BUFFER_POOL_SIZE, 0u);
  EXPECT_EQ(rdbms::INVALID_PAGE_ID, -1);
}
