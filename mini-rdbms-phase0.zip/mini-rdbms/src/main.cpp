// Entry point. For now this just proves the build/link/run pipeline works.
// Phase 6/7 will replace the loop body with: read SQL -> parse -> plan ->
// execute -> print result.
#include <iostream>
#include <string>

#include "common/config.h"

int main() {
  std::cout << "mini-rdbms (phase 0 skeleton)\n";
  std::cout << "page size = " << rdbms::PAGE_SIZE << " bytes, "
            << "buffer pool = " << rdbms::BUFFER_POOL_SIZE << " frames\n";
  std::cout << "type 'exit' to quit (no SQL support yet)\n";

  std::string line;
  while (true) {
    std::cout << "rdbms> ";
    if (!std::getline(std::cin, line)) break;
    if (line == "exit" || line == "quit") break;
    if (line.empty()) continue;
    std::cout << "(no-op) not implemented until the parser/executor phases\n";
  }
  return 0;
}
