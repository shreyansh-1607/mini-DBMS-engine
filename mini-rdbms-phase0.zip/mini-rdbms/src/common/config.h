// Global constants shared across every layer of the engine.
// Phase 0 decision record: these values are fixed now so later phases
// (buffer pool, B+ tree, table heap) don't each invent their own.
#pragma once

#include <cstdint>

namespace rdbms {

// Page size matches a typical OS page (4 KiB). Every on-disk read/write
// happens in units of this size — the disk manager never does partial
// page I/O.
constexpr uint32_t PAGE_SIZE = 4096;

// Number of frames the buffer pool holds in memory at once (Phase 2).
// Deliberately small so eviction behavior is easy to observe/test.
constexpr uint32_t BUFFER_POOL_SIZE = 64;

// Sentinel values.
constexpr int32_t INVALID_PAGE_ID = -1;
constexpr int32_t INVALID_TXN_ID = -1;
constexpr int16_t INVALID_SLOT = -1;

using page_id_t = int32_t;
using txn_id_t = int32_t;
using slot_id_t = int16_t;
using lsn_t = int32_t;  // log sequence number, used from Phase 9 onward

constexpr lsn_t INVALID_LSN = -1;

}  // namespace rdbms
