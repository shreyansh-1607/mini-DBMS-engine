// Single exception type for the engine. Later phases can subclass this
// (e.g. ParseException, LockConflictException) once there's real behavior
// to distinguish — Phase 0 just needs a place for errors to go.
#pragma once

#include <stdexcept>
#include <string>

namespace rdbms {

class RdbmsException : public std::runtime_error {
 public:
  explicit RdbmsException(const std::string& message)
      : std::runtime_error(message) {}
};

}  // namespace rdbms
