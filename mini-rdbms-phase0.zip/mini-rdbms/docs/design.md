# Design Decisions

This file is written *before* implementation, phase by phase, and updated as
decisions change. Phase 0 entries below are the scope-locking decisions that
prevent later scope creep.

## Phase 0 decisions

### SQL subset (locked scope for v1)
Supported:
- `CREATE TABLE name (col type, col type, ...)`
- `INSERT INTO name VALUES (...)`
- `SELECT col, col FROM name [WHERE col = value]` — single table only
- `UPDATE name SET col = value [WHERE ...]`
- `DELETE FROM name [WHERE ...]`

Deferred to stretch goals (do not implement until v1 above works end to end):
- Joins (`SELECT ... FROM a, b WHERE a.x = b.y`)
- Aggregates (`COUNT`, `SUM`, `GROUP BY`)
- Multiple WHERE conditions (`AND`/`OR` chains)
- `ALTER TABLE`, `DROP TABLE`

Types supported: `INT`, `VARCHAR(n)`. (No `FLOAT`/`DATE` in v1 — adds
serialization complexity without adding engine-design signal.)

### Page size
`4096` bytes (`PAGE_SIZE` in `src/common/config.h`), matching typical OS page
size. Every disk read/write is exactly one page — no partial-page I/O,
ever. This is what makes the buffer-pool-as-virtual-memory analogy hold.

### Buffer pool size
`64` frames to start. Small on purpose — makes eviction bugs visible in
testing instead of hiding behind a cache big enough to never evict.

### Execution model
Volcano/iterator (pull-based `Next()`) — chosen over a batch/vectorized
model because it's simpler to get correct first, and it's the model most
DBMS courses (e.g. CMU 15-445 / BusTub) use, so it's easy to explain and
compare against in an interview.

### Concurrency control (target, implemented in Phase 8)
Strict Two-Phase Locking (2PL) — chosen over MVCC for v1 because it's
easier to reason about correctness for, even though MVCC is what most
production databases (Postgres) actually use. MVCC noted as a stretch
goal / "what I'd do differently" talking point.

## Open questions for later phases
- B+ tree: support delete-rebalancing, or accept a slowly-degrading tree
  after deletes as a documented limitation? (Decide in Phase 5.)
- WAL: implement real ARIES redo/undo, or a simplified checkpoint-based
  scheme? (Decide in Phase 9.)
